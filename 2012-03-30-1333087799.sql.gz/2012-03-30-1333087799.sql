-- MySQL dump 10.13  Distrib 5.1.58, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: production_db
-- ------------------------------------------------------
-- Server version	5.1.58-1ubuntu1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attribs`
--

DROP TABLE IF EXISTS `attribs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attribs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribs`
--

LOCK TABLES `attribs` WRITE;
/*!40000 ALTER TABLE `attribs` DISABLE KEYS */;
/*!40000 ALTER TABLE `attribs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribs_geneds`
--

DROP TABLE IF EXISTS `attribs_geneds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attribs_geneds` (
  `gened_id` int(11) DEFAULT NULL,
  `attrib_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribs_geneds`
--

LOCK TABLES `attribs_geneds` WRITE;
/*!40000 ALTER TABLE `attribs_geneds` DISABLE KEYS */;
/*!40000 ALTER TABLE `attribs_geneds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buildings`
--

DROP TABLE IF EXISTS `buildings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buildings`
--

LOCK TABLES `buildings` WRITE;
/*!40000 ALTER TABLE `buildings` DISABLE KEYS */;
/*!40000 ALTER TABLE `buildings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configurations`
--

DROP TABLE IF EXISTS `configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configurations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configurations`
--

LOCK TABLES `configurations` WRITE;
/*!40000 ALTER TABLE `configurations` DISABLE KEYS */;
INSERT INTO `configurations` VALUES (1,'AA',1),(2,'AAS',2),(3,'AA',3),(4,'AA',4),(5,'BB',4),(6,'MM',5),(7,'RR',6),(8,'AA',7),(9,'BB',7),(10,'AA',8),(11,'AA',9),(12,'AA',10),(13,'AA',11),(14,'UU',12),(15,'AA',13),(16,'AA',14),(17,'AA',15),(18,'BB',15),(19,'NN',16),(20,'AA',17),(21,'AA',18),(22,'NN',19),(23,'NN',20),(24,'MM',21),(25,'AA',22),(26,'NN',23),(27,'AA',24),(28,'AA',25),(29,'A3',26),(30,'A4',26),(31,'TT',27),(32,'AA',28),(33,'AA',29),(34,'AA',30),(35,'VV',31),(36,'NN',32),(37,'NN',33),(38,'AA',34),(39,'LL',35),(40,'NN',36),(41,'AA',37),(42,'XX',37),(43,'YY',37),(44,'NN',38),(45,'NN',39),(46,'AA',40),(47,'BB',40),(48,'AA',41),(49,'AA',42),(50,'OO',43),(51,'AA',44),(52,'AA',45),(53,'AA',46),(54,'AA',47),(55,'AA',48),(56,'BB',48),(57,'CC',48),(58,'EE',48),(59,'FF',48),(60,'GG',48),(61,'AA',49),(62,'WW',49),(63,'DD',50),(64,'FF',51),(65,'AA',52),(66,'AA',53),(67,'BB',53),(68,'NN',54),(69,'MM',55),(70,'AA',56),(71,'BB',56),(72,'AA',57),(73,'BB',57),(74,'AA',58),(75,'AA',59),(76,'BB',59),(77,'CC',59),(78,'AA',60),(79,'BB',60),(80,'CC',60),(81,'DD',60),(82,'EE',61),(83,'AA',62),(84,'BB',62),(85,'CC',62),(86,'DD',62),(87,'EE',62),(88,'FF',62),(89,'AA',63),(90,'CC',63),(91,'AA',64),(92,'BB',64),(93,'CC',64),(94,'CC',65),(95,'CC',66),(96,'AA',67),(97,'BB',67),(98,'AA',68),(99,'AA',69),(100,'NN',70),(101,'AA',70),(102,'CC',70),(103,'FF',70),(104,'SS',70),(105,'AA',71),(106,'ACCY',72);
/*!40000 ALTER TABLE `configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subjectId` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `section_information` text COLLATE utf8_unicode_ci,
  `schedule_information` text COLLATE utf8_unicode_ci,
  `hours_min` int(11) DEFAULT NULL,
  `hours_max` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,100,'Interdisciplinary introduction to the basic concepts and approaches in Asian American Studies. Surveys the various dimensions of Asian American experiences including history, social organization, literature, arts, and politics.','Intro Asian American Studies','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(2,184,'Same as ANTH 184 and SOC 124. See ANTH 184.','Asian American Cultures','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(3,211,'Examination of Asian American artistic expressions in the visual and the performing arts providing historical, theoretical, and conceptual foundations of understanding the history of various art genres in Asian American communities. Prerequisite: AAS 100 or AAS 120, or consent of instructor.','Asian Americans and the Arts','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(4,250,'Intensive interdisciplinary study of a particular Asian American Ethnic group (specific ethnic group focus will change every semester). May be repeated in the same or separate terms to a maximum of 9 hours. Prerequisite: Any AAS course at the 100- or 200-level or consent of instructor.','Asian American Ethnic Groups','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(5,286,'Same as ENGL 286. See ENGL 286.','Asian American Literature','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(6,291,'Introduction to the historical, religious, and socio-cultural aspects of Hinduism in the US. The role of Hinduism in the maintenance of the ethnic identity of Indians in the US will be examined in the context of the rituals, languages, temples, family, and other social organizations. The maintenance and/or shift of the features of traditional (Indian) Hinduism in the transplanted counterpart in the US will be examined. Same as RLST 291. Prerequisite: RLST 104 or RLST 286 or consent of instructor.','Hinduism in the United States','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(7,310,'Same as AFRO 310, EPS 310, and LLS 310. See EPS 310.','Race and Cultural Diversity','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,4,4),(8,315,'Interdisciplinary examination of the ways that memories of warm, trauma, and immigration are produced through the medium of film. Because war has been key to discourses and practices of imperialism and globalization, some questions addressed will include how these wars have impacted the nation and the global order, as well as how images about these wars produced important constructions of race, gender, and sexuality for national and cultural identities. Also examines the aftereffects of war by analyzing connections between war\'s trauma, race, immigration, and incarceration. Students will read critical texts, film theory, screenplays, and view films. Same as GWS 315. Prerequisite: AAS 100 or AAS 120, or consent of the instructor.','War, Memory, and Cinema','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(9,346,'Explores cultural production of second-generation Asian American youth as a historical and social formation. Course examines how youth are actively shaping the U.S. landscape in terms of identity formation, youth, culture, education, juvenile justice, politics and activism, and community formations. These experiences are examined in backdrop of larger historical, economic, racial, social and political forces in the United States. Same as HDFS 341.','Asian American Youth','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(10,365,'An examination of media generally and films and videos more specifically (experimental, documentary, independent, and Hollywood features) by, for, and about Asian Americans. Same as MACS 365. Prerequisite: Any AAS course at the 100- or 200-level, or consent of instructor.','Asian American Media and Film','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,3),(11,402,'Same as EPS 402. See EPS 402.','Asian American Education','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,4,4),(12,435,'Same as AFRO 435, GWS 435, LLS 435, and MACS 432. See LLS 435.','Commodifying Difference','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,4),(13,490,'Research seminar on specialized topics in Asian American Studies. May be repeated if topics vary. Students may register in more than one section per term if topics vary. Prerequisite: AAS 100 or any Asian American Studies course, or consent of instructor.','Adv Topics in Asian Am Studies','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,3,4),(14,561,'Introduction to graduate level theoretical and methodological approaches in Comparative Race Studies. As a survey of theories of race and racism and the methodology of critique, this course offers an interdisciplinary approach that draws from anthropology, sociology, history, literature, cultural studies, and gender/sexuality studies. In addition, the study of racial and cultural formation is examined from a comparative perspective in the scholarship of racialized and Gender and Women\'s Studies. Same as AFRO 531, ANTH 565, GWS 561, and LLS 561.','Race and Cultural Critique','AAS',NULL,1,'2012-03-29 00:21:28','2012-03-29 00:21:28',NULL,NULL,4,4),(15,100,'Introduction to the engineering profession with career opportunities in the agricultural and biological engineering discipline. Concepts necessary for becoming a successful engineer including time management, design concepts, ethics, and teambuilding. Familiarization with laboratories, computer facilities, internships, and other opportunities. Team design experience. Emphasis on technical communication and problem-solving skills as well as career planning.','Intro Agric & Biological Engrg','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,1,1),(16,199,'May be repeated to a maximum of 12 hours.','Undergraduate Open Seminar','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,1,5),(17,223,'Machinery systems for off-road applications: internal combustion engines; fluid power; tractors, and traction; chemical application; grain harvesting. Prerequisite: One of MATH 220, MATH 221, MATH 234.','ABE Principles: Machine Syst','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,2,2),(18,224,'Engineering principles and methods of design and management of natural resources and environmental systems; watershed and hydrologic cycle; infiltration and surveying; runoff and erosion; water quality; non-point source pollution. Prerequisite: One of MATH 220, MATH 221, MATH 234.','ABE Principles: Soil & Water','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,2,2),(19,225,'Principles of environmental control for biological structures: psychrometrics; mass and heat transfer through buildings; ventilation requirements. Prerequisite: One of MATH 220, MATH 221, MATH 234.','ABE Principles: Bioenvironment','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,2,2),(20,226,'Principles of bioprocess engineering applied to food and agricultural products: material balances; fluid flow; heat and mass transfers; drying; evaporation; fermentation; distillation; process simulation. Prerequisite: One of MATH 220, MATH 221, MATH 234.','ABE Principles: Bioprocessing','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,2,2),(21,341,'Principles of transport processes involving momentum, heat, and mass as applied to biological systems in agriculture, food, energy, and the environment. Credit is not given for both ABE 341 and CHBE 421. Prerequisite: ABE 223, ABE 224, ABE 225, ABE 226, and PHYS 213.','Transport Processes in ABE','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,3),(22,361,'Design and development concepts of agricultural and industrial machines; analysis and synthesis of tillage, planting, harvesting, chemical application, material handling mechanisms, and precision farming tools. Prerequisite: ABE 223 and TAM 212.','Off-Road Machine Design','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,3),(23,397,'Individual research, special problems, thesis, development or design work under the supervision of a member of the faculty. May be repeated to a maximum of 8 hours. Prerequisite: Consent of instructor.','Independent Study','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,1,4),(24,430,'Engineering team effectiveness; project definition; assessing related technologies; marketing and business planning related to engineering; budgeting and financial analyses of engineering projects; safety, ethics and environmental considerations; intellectual property; engineering proposal presentation. Same as TSM 430.','Project Management','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,2,2),(25,440,'Same as ANSC 440, CPSC 440, FSHN 440, and NRES 440. See CPSC 440. ','Applied Statistical Methods I','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,4,4),(26,459,'Design, construction, performance, and maintenance of agricultural drainage systems to meet both production and water quality objectives. Modeling drainage systems. Principles of conservation drainage. 3 undergraduate hours. 3 or 4 graduate hours. Prerequisite: Credit or concurrent registration in TAM 335.','Drainage and Water Management','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,4),(27,463,'Engineering principles of electrohydraulic control systems related to off-road vehicles. Basics of fluid power systems, concepts of electrohydraulic systems and controls, analysis and design of electrohydraulic control systems, and applications of electrohydraulic control. Prerequisite: ECE 110 or both ECE 205 and ECE 206; ME 310 or TAM 335.','Electrohydraulic Systems','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,3),(28,466,'Design and application of off-road vehicles for farm and construction use; thermodynamics of engines; measurement of power and efficiencies; power transmission and traction; chassis mechanics; operator environment. Credit is not given for both ABE 466 and TSM 464. Prerequisite: ME 300.','Engineering Off-Road Vehicles','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,3),(29,482,'Same as FSHN 469. See FSHN 469.','Package Engineering','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,3),(30,483,'Physical properties of foods and biological materials; properties relating to equipment design and the sensing and control of food processes; thermal, electromagnetic radiation, rheological, and other mechanical properties. Prerequisite: TAM 251; either CHBE 421 or both ME 330 and TAM 335.','Engrg Properties of Food Matls','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,3),(31,488,'Engineering and scientific principles governing bioprocessing of biomass for production of ethanol and other fermentation products. Process unit operations; conventional and alternative feed stock materials; recovery of value-added coproducts and other variables involved in producing fuel ethanol; process simulation; economic analysis. Prerequisite: CHBE 321 and TAM 335.','Bioprocessing Biomass for Fuel','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,3,3),(32,497,'Individual research, special problems, thesis, development or design work under the supervision of a member of the faculty. No graduate credit. May be repeated to a maximum of 8 hours. Prerequisite: Consent of instructor.','Independent Study','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,1,4),(33,498,'Subject offerings of new and developing areas of knowledge in agricultural and biological engineering intended to augment the existing curriculum. See Class Schedule or departmental course information for topics and prerequisites. May be repeated in the same or separate terms if topics vary to a maximum of 16 hours.','Special Topics','ABE',NULL,2,'2012-03-29 00:21:32','2012-03-29 00:21:32',NULL,NULL,1,4),(34,501,'Basic research orientation, research methods, presentation skills, laboratory practices, case studies, and professional and ethical conduct.','Graduate Research I','ABE',NULL,2,'2012-03-29 00:21:33','2012-03-29 00:21:33',NULL,NULL,1,1),(35,594,'Presentations of thesis research by graduate students; other presentations on teaching or current research issues related to agricultural and biological engineering. Approved for S/U grading only. May be repeated up to a maximum of 6 times.','Graduate Seminar','ABE',NULL,2,'2012-03-29 00:21:33','2012-03-29 00:21:33',NULL,NULL,0,0),(36,597,'Individual investigations or studies of any phases of agricultural engineering selected by the student and approved by the advisor and the faculty member who will supervise the study. May be repeated to a maximum of 16 hours. Prerequisite: Consent of instructor.','Independent Study','ABE',NULL,2,'2012-03-29 00:21:33','2012-03-29 00:21:33',NULL,NULL,1,4),(37,598,'Subject offerings of new and developing areas of knowledge in agricultural and biological engineering intended to augment the existing curriculum. See Class Schedule or departmental course information for topics and prerequisites. May be repeated in the same or separate terms if topics vary to a maximum of 8 hours.','Special Topics','ABE',NULL,2,'2012-03-29 00:21:33','2012-03-29 00:21:33',NULL,NULL,1,4),(38,599,'Approved for S/U grading only. May be repeated.','Thesis Research','ABE',NULL,2,'2012-03-29 00:21:33','2012-03-29 00:21:33',NULL,NULL,NULL,NULL),(39,199,'May be repeated.','Undergraduate Open Seminar','ACCY',NULL,3,'2012-03-29 00:21:39','2012-03-29 00:21:39',NULL,NULL,1,5),(40,200,'Survey course in the principles of accounting for students registered in schools and colleges other than the College of Business. Credit is not given for both ACCY 200 and either ACCY 201 or ACCY 202. Prerequisite: Sophomore standing.','Fundamentals of Accounting','ACCY',NULL,3,'2012-03-29 00:21:39','2012-03-29 00:21:39',NULL,NULL,3,3),(41,201,'Introduction to the role of accounting information in establishing organization objectives and goals and identification of strategies to best achieve such objectives and goals. Topics focus on the utility of information necessary for the formation, execution and monitoring of the variety of contracts embedded in organization strategies. Projects facilitate self-discovery of knowledge and development of a variety of professional skills and attitudes. Credit is not given for both ACCY 201 and ACCY 200. Prerequisite: ECON 102 and ECON 103 or equivalents. ','Accounting and Accountancy I','ACCY',NULL,3,'2012-03-29 00:21:39','2012-03-29 00:21:39',NULL,NULL,3,3),(42,202,'Continuation of ACCY 201 with focus on strategic management of economic resources, together with acquisition of such resources, and financial and non-financial measures of organizational performance. Credit is not given for both ACCY 202 and ACCY 200. Prerequisite: ACCY 201 or equivalent. ','Accounting and Accountancy II','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,3,3),(43,290,'Formalized learning experience in combination with practice of accounting while engaged in an internship with a public accounting firm, business, or other off-campus organization; prior approval of learning plan and a summary report of learning experience are required. Approved for both letter and S/U grading. May be repeated in the same or subsequent terms to a maximum of 3 hours. Prerequisite: Open only to undergraduate accountancy majors with junior or senior standing; completion of 300-level accountancy courses appropriate to internship learning plan; and consent of department.','Prof Internship in Accountancy','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,0,3),(44,301,'Introduction to measurement and reporting of organizational performance for strategic and operational purposes with a focus on a variety of financial and non-financial performance measures suitable for both internal and external decision-making. Projects, together with a series of practical workshops, facilitate self-discovery of knowledge and development of a variety of professional skills and attitudes. Prerequisite: ACCY 202 or equivalent and concurrent enrollment in ACCY 302 by students majoring in accountancy (recommended for non-accountancy majors); or consent of department. ','Atg Measurement & Disclosure','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(45,302,'Decision making implications of information provided to organization managers and to external stakeholders such as investors, creditors, customers, and regulators. Concepts from economics, statistics, and psychology emphasize the use of quantitative techniques to comprehend uncertainty and risk. Projects, together with a series of practical workshops, facilitate self-discovery of knowledge and development of a variety of professional skills and attitudes. Prerequisite: ACCY 202 or equivalent; ECON 203 or equivalent or concurrent enrollment; and concurrent enrollment in ACCY 301 by students majoring in Accountancy (recommended for non-Accountancy majors); or consent of department. ','Decision Making for Atg','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(46,303,'Regulation theory and practice as applied to accounting information. A general framework for regulation of accounting procedures is developed. This framework is applied to reporting, taxation, and regulated business activities. Projects facilitate self-discovery of knowledge and the development of professional attitudes and skills with emphasis on professional research. Prerequisite: ACCY 301 and ECON 302 and FIN 221; or consent of department. ','Atg Institutions and Reg','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(47,304,'Broad perspective on accounting and control that considers attainment of all goals of an organization, including those concerned with financial objectives. Topics include the conceptual foundations of control and application of practical, analytical tools to the evaluation of an organization\'s control environment. Cases, class discussion and field research projects emphasize independent thinking, group processes, and communication. Prerequisite: ACCY 301 and ACCY 302 and BADM 310; or consent of department. ','Accounting Control Systems','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(48,312,'Introduction to the tax system faced by businesses operating in the United States with a focus on the impact that the tax system has on business decisions. Topics include the tax environment, tax provisions relevant to businesses and their owners, taxation of individuals and of corporations, and multi-jurisdictional issues. Projects facilitate self-discovery of knowledge and development of a variety of professional skills and attitudes. Prerequisite: ACCY 202 or equivalent.','Principles of Taxation','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(49,321,'Same as BADM 303 and PS 321. See PS 321.','Principles of Public Policy','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,3,3),(50,352,'Same as BADM 352. See BADM 352.','Database Design and Management','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,3,3),(51,353,'Same as BADM 353. See BADM 353.','Info Sys Analysis and Design','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,3,3),(52,405,'Conceptual introduction to diverse means by which assurers improve the quality of information used by third parties for contracting purposes, with emphases on the credibility- and relevance-enhancement properties of assurers\' services. Topics include the economics of assurance and attestation, and concepts including independence, risk, evidence, and control. Projects facilitate self-discovery of knowledge and development of professional skills and attitudes. Prerequisite: ACCY 304 or consent of department. ','Assurance and Attestation','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(53,451,'Practical and theoretical training in the more common and important provisions of the federal income tax, advanced problems, and tax case research and preparation. 3 undergraduate hours. 3 or 4 graduate hours. Prerequisite: Senior standing and ACCY 312.','Advanced Income Tax Problems','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,3,4),(54,499,'Research and readings course for students majoring in accountancy. May be taken by students in the college honors program in partial fulfillment of the honors requirements. No graduate credit. May be repeated to a maximum of 6 hours. Prerequisite: Cumulative grade-point average of 3.0., honors in the junior year, or consent of department; senior standing.','Senior Research','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,2,4),(55,500,'A managerial perspective of the nature and role of accounting in organization measurement, reporting and control processes. Prerequisite: Enrollment in a non-accountancy masters program in business or consent of department.','Atg Measuremnt, Rpting & Cntrl','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,1,4),(56,502,'In-depth study of accounting valuation processes, accounting income measurement, and special reporting problems of multiple-entity organizations. Prerequisite: ACCY 501 or equivalent; enrollment in graduate degree program or consent of department.','Accounting Analysis II','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(57,503,'Introduction to management accounting as part of the firm\'s information system, in terms of modern cost accounting and budgetary systems for planning and controlling business operations. Prerequisite: Credit or concurrent registration in ACCY 501 or equivalent; enrollment in graduate degree program or consent of department.','Managerial Accounting','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(58,504,'Introduction to conceptual and applied material in the field of auditing. Emphasizes the audit process, reporting, and professional responsibilities. Prerequisite: Credit or concurrent registration in ACCY 502, or equivalent; enrollment in graduate degree program or consent of department.','Auditing','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(59,505,'Introduction to historical and conceptual as well as applied material in the accounting area of federal taxation; emphasizes the provisions of the tax law relevant to accounting measurement methods. Credit is not given for both ACCY 505 and ACCY 312. Prerequisite: ACCY 501; enrollment in graduate degree program or consent of department.','Federal Taxation','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(60,510,'Stakeholders\' needs for reliable and relevant information about the performance of firms, as well as managers; economic self-interests, influence managers\' selection of accounting policies and financial reporting methods. This course selectively surveys both academic research and professional standards to focus on the measurement, classification and disclosure of financial transactions. Cases, class discussion and research projects emphasize independent thinking, group processes, and communication. Prerequisite: ACCY 303, FIN 300 and enrollment in the BS/MS in Accountancy program or consent of department.','Financial Reporting Standards','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(61,511,'Application of the concepts of risk and uncertainty to the financial management of organizations in achieving business objectives and strategies, with an emphasis on the role of accounting measurement and reporting in the management of such risks. Focuses on integrating knowledge acquired from behavioral, economic, finance, and accounting perspectives. Prerequisite: ACCY 510 and enrollment in graduate accounting degree program or consent of department.','Risk Measurement/Reporting I','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(62,512,'Application of the concepts of risk and uncertainty to the operational management of organizations in achieving business objectives and strategies, with an emphasis on the role of accounting measurement and reporting in the management of such risks. Focuses on integrating knowledge acquired from behavioral, economic, organizational, and accounting perspectives. Prerequisite: Enrollment in graduate accounting degree program or consent of department.','Risk Measurement/Reporting II','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(63,515,'Role of professional and ethical standards in the conduct of auditing and assurance services and the role of auditing and assurance services in corporate governance. This course selectively surveys both academic and professional literature to focus on the conduct of auditing and assurance services. Cases, class discussion and research projects emphasize the importance of independent thinking, group processes, and communication for professional accounting practice.  Prerequisite: ACCY 405 and enrollment in the BS/MS in Accountancy program or consent of department.','Auditing & Assurance Standards','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(64,517,'Examines tools and techniques of financial statement analysis from the perspective of investors and creditors; emphasizes theoretical and empirical properties of financial ratios. Prerequisite: ACCY 501, FIN 520, BADM 572; or equivalent; and enrollment in graduate degree program or consent of department.','Financial Statement Analysis','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(65,552,'Analyzes the tax treatment, problems, planning techniques, and underlying governmental policies involving partnerships and their partners, including Subchapter S corporations and their shareholders. Prerequisite: ACCY 312 or equivalent.','Partnership Income Taxation','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(66,553,'Seminar on federal tax topics of current interest in specialized areas; topics include international taxation, deferred compensation, problems of closely-held businesses, estate planning, taxation of trusts, and new developments. May be repeated with the consent of the department. Prerequisite: ACCY 451 or consent of department.','Selected Topics in Fed Tax','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,2,4),(67,556,'Provides the student with a working knowledge of tax research methodology utilized by accountants in public practice. Aims to develop the student\'s capacity for either solving or defending his/her position with respect to a particular tax issue. Prerequisite: Graduate standing or consent of department.','Tax Research','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(68,585,'Examines the role of information in economic and behavioral models of decision making under uncertainty; presents major paradigms underlying contemporary accounting research. Interdisciplinary approach; readings drawn from the accounting, behavioral, economics, and finance literature. Prerequisite: MATH 463, ACCY 591, and ECON 502.','Constructs in Atg Research','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(69,592,'Comparative study of alternative methodologies and conceptual frameworks and their application to selected current research issues central to the development of accounting thought, both theoretical and empirical. Prerequisite: ACCY 511 and ACCY 512 and courses in behavioral science, mathematics, and economics; or equivalent background and admission to the accountancy Ph.D. program; or consent of department.','Intro to ACCY Research','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(70,593,'Individual investigations or research projects selected by the students, subject to approval by the graduate adviser and the executive officer of the Department. May be repeated in the same or separate terms. Prerequisite: Enrollment in graduate accounting degree program or consent of department.','Special Research Problems','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,1,8),(71,594,'Seminars in various accounting areas designed to enhance the research abilities of doctoral students and to assist them in preparing research proposals; these include Behavioral Dimensions, Public Sector, Tax, Auditing, Managerial, and others announced in the Class Schedule. May be repeated. Prerequisite: Credit or concurrent registration in ACCY 592 or consent of department.','Doctoral Research Seminar','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,4,4),(72,599,'Individual direction and guidance in writing theses; seminar discussion of progress made. Approved for S/U grading only.','Thesis Research','ACCY',NULL,3,'2012-03-29 00:21:40','2012-03-29 00:21:40',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses_users`
--

DROP TABLE IF EXISTS `courses_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses_users` (
  `user_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses_users`
--

LOCK TABLES `courses_users` WRITE;
/*!40000 ALTER TABLE `courses_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `courses_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friendships`
--

DROP TABLE IF EXISTS `friendships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friendships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `friend_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friendships`
--

LOCK TABLES `friendships` WRITE;
/*!40000 ALTER TABLE `friendships` DISABLE KEYS */;
/*!40000 ALTER TABLE `friendships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geneds`
--

DROP TABLE IF EXISTS `geneds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geneds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geneds`
--

LOCK TABLES `geneds` WRITE;
/*!40000 ALTER TABLE `geneds` DISABLE KEYS */;
/*!40000 ALTER TABLE `geneds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geneds_courses`
--

DROP TABLE IF EXISTS `geneds_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geneds_courses` (
  `gened_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geneds_courses`
--

LOCK TABLES `geneds_courses` WRITE;
/*!40000 ALTER TABLE `geneds_courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `geneds_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructors_meetings`
--

DROP TABLE IF EXISTS `instructors_meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instructors_meetings` (
  `meeting_id` int(11) DEFAULT NULL,
  `instructor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructors_meetings`
--

LOCK TABLES `instructors_meetings` WRITE;
/*!40000 ALTER TABLE `instructors_meetings` DISABLE KEYS */;
/*!40000 ALTER TABLE `instructors_meetings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20110910013255'),('20110910020523'),('20110910021441'),('20110910030123'),('20110910031109'),('20110910064216'),('20110915012925'),('20110915013157'),('20110915180150'),('20110918044800'),('20110929001027'),('20110929025452'),('20110929043437'),('20110929062142'),('20111002164122'),('20111021045403'),('20111021050239'),('20111021050842'),('20111103042957'),('20111103050132'),('20111105222219'),('20111105235453'),('20111106040806'),('20111108044901'),('20120202015132'),('20120202015314'),('20120202015741'),('20120202015831'),('20120202020316'),('20120202022206'),('20120202022656'),('20120202022930'),('20120202023054'),('20120202023125'),('20120202023820'),('20120202031130'),('20120202032347'),('20120202035926'),('20120202041408'),('20120202042500'),('20120202045438'),('20120202045827'),('20120202050335'),('20120202052217'),('20120216005552'),('20120216012015'),('20120217015621'),('20120217023817'),('20120311212254'),('20120311221346'),('20120316011855'),('20120316040326'),('20120316174928'),('20120319012833'),('20120320172821'),('20120327020048'),('20120327030255'),('20120327044229'),('20120328033643');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schools` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_number` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `section_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `course_subject_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `course_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `course_number` int(11) DEFAULT NULL,
  `part_of_term` int(11) DEFAULT '0',
  `enrollment_status` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `special_approval` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration_id` int(11) DEFAULT NULL,
  `short_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hours` int(11) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,41758,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD1','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(2,47100,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD2','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(3,47102,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD3','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(4,51248,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD4','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(5,51249,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD5','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(6,51932,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD6','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(7,59818,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD7','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(8,59819,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD8','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(9,59820,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AD9','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(10,59821,NULL,'discussion-recitation',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','ADA','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(11,29646,NULL,'lecture',1,'2012-03-29 00:21:28','2012-03-29 00:21:28','AL1','AAS','Intro Asian American Studies',100,1,1,NULL,NULL,NULL,NULL,1,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(12,37061,NULL,'lecture-discussion',2,'2012-03-29 00:21:28','2012-03-29 00:21:28','1  ','AAS','Asian American Cultures',184,1,1,NULL,NULL,NULL,NULL,2,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(13,53947,NULL,'lecture-discussion',3,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','Asian Americans and the Arts',211,1,1,NULL,NULL,NULL,NULL,3,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(14,58090,NULL,'lecture-discussion',4,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','Asian American Ethnic Groups',250,1,1,NULL,NULL,NULL,NULL,4,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(15,58091,NULL,'lecture-discussion',4,'2012-03-29 00:21:28','2012-03-29 00:21:28','B  ','AAS','Asian American Ethnic Groups',250,1,1,NULL,NULL,NULL,NULL,5,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(16,41932,NULL,'lecture-discussion',5,'2012-03-29 00:21:28','2012-03-29 00:21:28','M  ','AAS','Asian American Literature',286,1,1,NULL,NULL,NULL,NULL,6,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(17,59944,NULL,'lecture-discussion',6,'2012-03-29 00:21:28','2012-03-29 00:21:28','RP ','AAS','Hinduism in the United States',291,1,2,NULL,NULL,NULL,NULL,7,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(18,33770,NULL,'discussion-recitation',7,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','Race and Cultural Diversity',310,1,1,NULL,NULL,NULL,NULL,8,'DIS',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(19,33764,NULL,'discussion-recitation',7,'2012-03-29 00:21:28','2012-03-29 00:21:28','B  ','AAS','Race and Cultural Diversity',310,1,1,NULL,NULL,NULL,NULL,9,'DIS',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(20,58268,NULL,'lecture-discussion',8,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','War, Memory, and Cinema',315,1,1,NULL,NULL,NULL,NULL,10,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(21,49995,NULL,'lecture-discussion',9,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','Asian American Youth',346,1,1,NULL,NULL,NULL,NULL,11,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(22,42862,NULL,'lecture-discussion',10,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','Asian American Media and Film',365,1,1,NULL,NULL,NULL,NULL,12,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(23,45567,NULL,'lecture-discussion',11,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','Asian American Education',402,1,2,NULL,NULL,NULL,NULL,13,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(24,60147,NULL,'lecture-discussion',12,'2012-03-29 00:21:28','2012-03-29 00:21:28','U  ','AAS','Commodifying Difference',435,1,2,NULL,NULL,NULL,NULL,14,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(25,31315,NULL,'conference',13,'2012-03-29 00:21:28','2012-03-29 00:21:28','ALO','AAS','Adv Topics in Asian Am Studies',490,1,2,NULL,NULL,NULL,NULL,15,'CNF',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(26,58576,NULL,'lecture-discussion',14,'2012-03-29 00:21:28','2012-03-29 00:21:28','A  ','AAS','Race and Cultural Critique',561,1,1,NULL,NULL,NULL,NULL,16,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(27,31260,NULL,'lecture',15,'2012-03-29 00:21:32','2012-03-29 00:21:32','A  ','ABE','Intro Agric & Biological Engrg',100,1,0,NULL,NULL,NULL,NULL,17,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(28,31263,NULL,'lecture',15,'2012-03-29 00:21:32','2012-03-29 00:21:32','B  ','ABE','Intro Agric & Biological Engrg',100,1,1,NULL,NULL,NULL,NULL,18,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(29,10141,NULL,'independent study',16,'2012-03-29 00:21:32','2012-03-29 00:21:32','NO CODE','ABE','Undergraduate Open Seminar',199,1,2,NULL,NULL,NULL,NULL,19,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(30,58928,NULL,'laboratory',17,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB1','ABE','ABE Principles: Machine Syst',223,0,1,NULL,NULL,NULL,NULL,20,'LAB',0,'2012-08-27 05:00:00','2012-10-19 05:00:00'),(31,58929,NULL,'laboratory',17,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB2','ABE','ABE Principles: Machine Syst',223,0,1,NULL,NULL,NULL,NULL,20,'LAB',0,'2012-08-27 05:00:00','2012-10-19 05:00:00'),(32,58930,NULL,'laboratory',17,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB3','ABE','ABE Principles: Machine Syst',223,0,1,NULL,NULL,NULL,NULL,20,'LAB',0,'2012-08-27 05:00:00','2012-10-19 05:00:00'),(33,58927,NULL,'lecture',17,'2012-03-29 00:21:32','2012-03-29 00:21:32','AL1','ABE','ABE Principles: Machine Syst',223,0,1,NULL,NULL,NULL,NULL,20,'LEC',0,'2012-08-27 05:00:00','2012-10-19 05:00:00'),(34,58932,NULL,'laboratory',18,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB1','ABE','ABE Principles: Soil & Water',224,0,1,NULL,NULL,NULL,NULL,21,'LAB',0,'2012-10-22 05:00:00','2012-12-12 06:00:00'),(35,58933,NULL,'laboratory',18,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB2','ABE','ABE Principles: Soil & Water',224,0,1,NULL,NULL,NULL,NULL,21,'LAB',0,'2012-10-22 05:00:00','2012-12-12 06:00:00'),(36,58931,NULL,'lecture',18,'2012-03-29 00:21:32','2012-03-29 00:21:32','AL1','ABE','ABE Principles: Soil & Water',224,0,1,NULL,NULL,NULL,NULL,21,'LEC',0,'2012-10-22 05:00:00','2012-12-12 06:00:00'),(37,58957,NULL,'lecture',19,'2012-03-29 00:21:32','2012-03-29 00:21:32','NO CODE','ABE','ABE Principles: Bioenvironment',225,1,0,NULL,NULL,NULL,NULL,22,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(38,58956,NULL,'lecture',20,'2012-03-29 00:21:32','2012-03-29 00:21:32','NO CODE','ABE','ABE Principles: Bioprocessing',226,1,0,NULL,NULL,NULL,NULL,23,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(39,57598,NULL,'lecture',21,'2012-03-29 00:21:32','2012-03-29 00:21:32','MGD','ABE','Transport Processes in ABE',341,1,1,NULL,NULL,NULL,NULL,24,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(40,29647,NULL,'laboratory',22,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB1','ABE','Off-Road Machine Design',361,1,1,NULL,NULL,NULL,NULL,25,'LAB',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(41,29651,NULL,'lecture',22,'2012-03-29 00:21:32','2012-03-29 00:21:32','AL1','ABE','Off-Road Machine Design',361,1,1,NULL,NULL,NULL,NULL,25,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(42,50272,NULL,'independent study',23,'2012-03-29 00:21:32','2012-03-29 00:21:32','NO CODE','ABE','Independent Study',397,1,0,NULL,NULL,NULL,NULL,26,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(43,36669,NULL,'lecture-discussion',24,'2012-03-29 00:21:32','2012-03-29 00:21:32','A  ','ABE','Project Management',430,1,2,NULL,NULL,NULL,NULL,27,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(44,33575,NULL,'lecture',25,'2012-03-29 00:21:32','2012-03-29 00:21:32','AL1','ABE','Applied Statistical Methods I',440,1,1,NULL,NULL,NULL,NULL,28,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(45,33576,NULL,'laboratory-discussion',25,'2012-03-29 00:21:32','2012-03-29 00:21:32','AY1','ABE','Applied Statistical Methods I',440,1,1,NULL,NULL,NULL,NULL,28,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(46,34047,NULL,'laboratory-discussion',25,'2012-03-29 00:21:32','2012-03-29 00:21:32','AY3','ABE','Applied Statistical Methods I',440,1,1,NULL,NULL,NULL,NULL,28,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(47,34061,NULL,'laboratory-discussion',25,'2012-03-29 00:21:32','2012-03-29 00:21:32','AY4','ABE','Applied Statistical Methods I',440,1,1,NULL,NULL,NULL,NULL,28,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(48,34085,NULL,'laboratory-discussion',25,'2012-03-29 00:21:32','2012-03-29 00:21:32','AY5','ABE','Applied Statistical Methods I',440,1,1,NULL,NULL,NULL,NULL,28,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(49,55892,NULL,'laboratory-discussion',25,'2012-03-29 00:21:32','2012-03-29 00:21:32','AY6','ABE','Applied Statistical Methods I',440,1,1,NULL,NULL,NULL,NULL,28,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(50,29655,NULL,'laboratory',26,'2012-03-29 00:21:32','2012-03-29 00:21:32','A3 ','ABE','Drainage and Water Management',459,1,1,NULL,NULL,NULL,NULL,29,'LAB',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(51,39805,NULL,'laboratory',26,'2012-03-29 00:21:32','2012-03-29 00:21:32','A4 ','ABE','Drainage and Water Management',459,1,2,NULL,NULL,NULL,NULL,30,'LAB',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(52,56114,NULL,'laboratory',27,'2012-03-29 00:21:32','2012-03-29 00:21:32','TEG','ABE','Electrohydraulic Systems',463,1,1,NULL,NULL,NULL,NULL,31,'LAB',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(53,31273,NULL,'laboratory',28,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB1','ABE','Engineering Off-Road Vehicles',466,1,1,NULL,NULL,NULL,NULL,32,'LAB',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(54,31277,NULL,'laboratory',28,'2012-03-29 00:21:32','2012-03-29 00:21:32','AB2','ABE','Engineering Off-Road Vehicles',466,1,1,NULL,NULL,NULL,NULL,32,'LAB',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(55,31280,NULL,'lecture',28,'2012-03-29 00:21:32','2012-03-29 00:21:32','AL1','ABE','Engineering Off-Road Vehicles',466,1,1,NULL,NULL,NULL,NULL,32,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(56,37689,NULL,'lecture',29,'2012-03-29 00:21:32','2012-03-29 00:21:32','A  ','ABE','Package Engineering',482,1,1,NULL,NULL,NULL,NULL,33,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(57,29663,NULL,'lecture',30,'2012-03-29 00:21:32','2012-03-29 00:21:32','A  ','ABE','Engrg Properties of Food Matls',483,1,1,NULL,NULL,NULL,NULL,34,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(58,57478,NULL,'lecture',31,'2012-03-29 00:21:32','2012-03-29 00:21:32','VS ','ABE','Bioprocessing Biomass for Fuel',488,1,1,NULL,NULL,NULL,NULL,35,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(59,50183,NULL,'independent study',32,'2012-03-29 00:21:32','2012-03-29 00:21:32','NO CODE','ABE','Independent Study',497,1,2,NULL,NULL,NULL,NULL,36,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(60,10169,NULL,'independent study',33,'2012-03-29 00:21:33','2012-03-29 00:21:33','NO CODE','ABE','Special Topics',498,1,2,NULL,NULL,NULL,NULL,37,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(61,39806,NULL,'lecture-discussion',34,'2012-03-29 00:21:33','2012-03-29 00:21:33','A  ','ABE','Graduate Research I',501,1,1,NULL,NULL,NULL,NULL,38,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(62,47356,NULL,'lecture-discussion',35,'2012-03-29 00:21:33','2012-03-29 00:21:33','LB1','ABE','Graduate Seminar',594,1,1,NULL,NULL,NULL,NULL,39,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(63,10174,NULL,'independent study',36,'2012-03-29 00:21:33','2012-03-29 00:21:33','NO CODE','ABE','Independent Study',597,1,2,NULL,NULL,NULL,NULL,40,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(64,55120,NULL,'discussion-recitation',37,'2012-03-29 00:21:33','2012-03-29 00:21:33','ACH','ABE','Special Topics',598,1,1,NULL,NULL,NULL,NULL,41,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(65,52854,NULL,'laboratory-discussion',37,'2012-03-29 00:21:33','2012-03-29 00:21:33','XW ','ABE','Special Topics',598,1,0,NULL,NULL,NULL,NULL,42,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(66,52855,NULL,'laboratory-discussion',37,'2012-03-29 00:21:33','2012-03-29 00:21:33','YZ ','ABE','Special Topics',598,1,1,NULL,NULL,NULL,NULL,43,'LBD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(67,10177,NULL,'independent study',38,'2012-03-29 00:21:33','2012-03-29 00:21:33','NO CODE','ABE','Thesis Research',599,1,2,NULL,NULL,NULL,NULL,44,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(68,10033,NULL,'independent study',39,'2012-03-29 00:21:39','2012-03-29 00:21:39','NO CODE','ACCY','Undergraduate Open Seminar',199,1,2,NULL,NULL,NULL,NULL,45,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(69,29670,NULL,'lecture-discussion',40,'2012-03-29 00:21:39','2012-03-29 00:21:39','A  ','ACCY','Fundamentals of Accounting',200,1,2,NULL,NULL,NULL,NULL,46,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(70,39539,NULL,'lecture-discussion',40,'2012-03-29 00:21:39','2012-03-29 00:21:39','B  ','ACCY','Fundamentals of Accounting',200,1,2,NULL,NULL,NULL,NULL,47,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(71,36478,NULL,'discussion-recitation',41,'2012-03-29 00:21:39','2012-03-29 00:21:39','AD1','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(72,36482,NULL,'discussion-recitation',41,'2012-03-29 00:21:39','2012-03-29 00:21:39','AD3','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(73,36484,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD4','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(74,36486,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD6','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(75,36487,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD7','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(76,36489,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD8','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(77,36494,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADA','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(78,36496,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADB','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(79,36499,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADC','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(80,36502,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADD','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(81,36506,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADE','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(82,36509,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADF','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(83,36516,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADH','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(84,36522,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADI','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(85,36526,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADJ','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(86,36536,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADL','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(87,36538,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADM','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(88,36543,NULL,'discussion-recitation',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','ADN','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(89,36474,NULL,'lecture',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','AL1','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(90,36477,NULL,'lecture',41,'2012-03-29 00:21:40','2012-03-29 00:21:40','AL2','ACCY','Accounting and Accountancy I',201,1,1,NULL,NULL,NULL,NULL,48,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(91,36552,NULL,'discussion-recitation',42,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD1','ACCY','Accounting and Accountancy II',202,1,1,NULL,NULL,NULL,NULL,49,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(92,36556,NULL,'discussion-recitation',42,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD2','ACCY','Accounting and Accountancy II',202,1,1,NULL,NULL,NULL,NULL,49,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(93,36560,NULL,'discussion-recitation',42,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD3','ACCY','Accounting and Accountancy II',202,1,1,NULL,NULL,NULL,NULL,49,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(94,36565,NULL,'discussion-recitation',42,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD4','ACCY','Accounting and Accountancy II',202,1,1,NULL,NULL,NULL,NULL,49,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(95,36568,NULL,'discussion-recitation',42,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD5','ACCY','Accounting and Accountancy II',202,1,1,NULL,NULL,NULL,NULL,49,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(96,36574,NULL,'discussion-recitation',42,'2012-03-29 00:21:40','2012-03-29 00:21:40','AD6','ACCY','Accounting and Accountancy II',202,1,1,NULL,NULL,NULL,NULL,49,'DIS',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(97,36549,NULL,'lecture',42,'2012-03-29 00:21:40','2012-03-29 00:21:40','AL1','ACCY','Accounting and Accountancy II',202,1,1,NULL,NULL,NULL,NULL,49,'LEC',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(98,45794,NULL,'conference',43,'2012-03-29 00:21:40','2012-03-29 00:21:40','O  ','ACCY','Prof Internship in Accountancy',290,1,2,NULL,NULL,NULL,NULL,50,'CNF',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(99,36577,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE1','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(100,36581,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE2','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(101,36584,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE3','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(102,36587,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE4','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(103,36590,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE5','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(104,36592,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE6','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(105,36598,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE8','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(106,49255,NULL,'lecture-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AEB','ACCY','Atg Measurement & Disclosure',301,1,2,NULL,NULL,NULL,NULL,51,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(107,36602,NULL,'laboratory-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AY1','ACCY','Atg Measurement & Disclosure',301,1,1,NULL,NULL,NULL,NULL,51,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(108,36605,NULL,'laboratory-discussion',44,'2012-03-29 00:21:40','2012-03-29 00:21:40','AY2','ACCY','Atg Measurement & Disclosure',301,1,1,NULL,NULL,NULL,NULL,51,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(109,36610,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE1','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(110,36614,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE2','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(111,36618,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE3','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(112,36677,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE4','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(113,36680,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE5','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(114,36688,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE8','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(115,49257,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE9','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(116,49258,NULL,'lecture-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AEA','ACCY','Decision Making for Atg',302,1,2,NULL,NULL,NULL,NULL,52,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(117,36690,NULL,'laboratory-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AY1','ACCY','Decision Making for Atg',302,1,1,NULL,NULL,NULL,NULL,52,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(118,36691,NULL,'laboratory-discussion',45,'2012-03-29 00:21:40','2012-03-29 00:21:40','AY2','ACCY','Decision Making for Atg',302,1,1,NULL,NULL,NULL,NULL,52,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(119,36692,NULL,'lecture-discussion',46,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE1','ACCY','Atg Institutions and Reg',303,1,2,NULL,NULL,NULL,NULL,53,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(120,36700,NULL,'lecture-discussion',46,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE2','ACCY','Atg Institutions and Reg',303,1,2,NULL,NULL,NULL,NULL,53,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(121,36701,NULL,'lecture-discussion',46,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE3','ACCY','Atg Institutions and Reg',303,1,2,NULL,NULL,NULL,NULL,53,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(122,36713,NULL,'lecture-discussion',46,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE4','ACCY','Atg Institutions and Reg',303,1,2,NULL,NULL,NULL,NULL,53,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(123,49259,NULL,'lecture-discussion',46,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE5','ACCY','Atg Institutions and Reg',303,1,2,NULL,NULL,NULL,NULL,53,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(124,36703,NULL,'lecture-discussion',46,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE6','ACCY','Atg Institutions and Reg',303,1,0,NULL,NULL,NULL,NULL,53,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(125,36721,NULL,'laboratory-discussion',46,'2012-03-29 00:21:40','2012-03-29 00:21:40','AY1','ACCY','Atg Institutions and Reg',303,1,1,NULL,NULL,NULL,NULL,53,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(126,31317,NULL,'lecture-discussion',47,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE1','ACCY','Accounting Control Systems',304,1,2,NULL,NULL,NULL,NULL,54,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(127,31318,NULL,'lecture-discussion',47,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE2','ACCY','Accounting Control Systems',304,1,2,NULL,NULL,NULL,NULL,54,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(128,31319,NULL,'lecture-discussion',47,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE3','ACCY','Accounting Control Systems',304,1,2,NULL,NULL,NULL,NULL,54,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(129,31320,NULL,'lecture-discussion',47,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE4','ACCY','Accounting Control Systems',304,1,2,NULL,NULL,NULL,NULL,54,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(130,49280,NULL,'lecture-discussion',47,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE5','ACCY','Accounting Control Systems',304,1,2,NULL,NULL,NULL,NULL,54,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(131,31316,NULL,'laboratory-discussion',47,'2012-03-29 00:21:40','2012-03-29 00:21:40','AY1','ACCY','Accounting Control Systems',304,1,1,NULL,NULL,NULL,NULL,54,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(132,31321,NULL,'lecture-discussion',48,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Principles of Taxation',312,1,2,NULL,NULL,NULL,NULL,55,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(133,31324,NULL,'lecture-discussion',48,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Principles of Taxation',312,1,2,NULL,NULL,NULL,NULL,56,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(134,31330,NULL,'lecture-discussion',48,'2012-03-29 00:21:40','2012-03-29 00:21:40','C  ','ACCY','Principles of Taxation',312,1,2,NULL,NULL,NULL,NULL,57,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(135,31333,NULL,'lecture-discussion',48,'2012-03-29 00:21:40','2012-03-29 00:21:40','E  ','ACCY','Principles of Taxation',312,1,2,NULL,NULL,NULL,NULL,58,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(136,45719,NULL,'lecture-discussion',48,'2012-03-29 00:21:40','2012-03-29 00:21:40','F  ','ACCY','Principles of Taxation',312,1,2,NULL,NULL,NULL,NULL,59,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(137,45934,NULL,'lecture-discussion',48,'2012-03-29 00:21:40','2012-03-29 00:21:40','G  ','ACCY','Principles of Taxation',312,1,2,NULL,NULL,NULL,NULL,60,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(138,41351,NULL,'lecture-discussion',49,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Principles of Public Policy',321,0,0,NULL,NULL,NULL,NULL,61,'LCD',0,'2012-08-27 05:00:00','2012-10-19 05:00:00'),(139,60065,NULL,'conference',49,'2012-03-29 00:21:40','2012-03-29 00:21:40','WA ','ACCY','Principles of Public Policy',321,1,2,NULL,NULL,NULL,'Instructor Approval Required',62,'CNF',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(140,37947,NULL,'lecture-discussion',50,'2012-03-29 00:21:40','2012-03-29 00:21:40','D  ','ACCY','Database Design and Management',352,1,1,NULL,NULL,NULL,NULL,63,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(141,37945,NULL,'lecture-discussion',51,'2012-03-29 00:21:40','2012-03-29 00:21:40','F  ','ACCY','Info Sys Analysis and Design',353,1,1,NULL,NULL,NULL,NULL,64,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(142,36754,NULL,'lecture-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE1','ACCY','Assurance and Attestation',405,1,2,NULL,NULL,NULL,NULL,65,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(143,36758,NULL,'lecture-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE2','ACCY','Assurance and Attestation',405,1,2,NULL,NULL,NULL,NULL,65,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(144,36764,NULL,'lecture-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE3','ACCY','Assurance and Attestation',405,1,2,NULL,NULL,NULL,NULL,65,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(145,36768,NULL,'lecture-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE4','ACCY','Assurance and Attestation',405,1,2,NULL,NULL,NULL,NULL,65,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(146,36771,NULL,'lecture-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE5','ACCY','Assurance and Attestation',405,1,2,NULL,NULL,NULL,NULL,65,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(147,36775,NULL,'lecture-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE6','ACCY','Assurance and Attestation',405,1,2,NULL,NULL,NULL,NULL,65,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(148,54162,NULL,'lecture-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AE7','ACCY','Assurance and Attestation',405,1,2,NULL,NULL,NULL,NULL,65,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(149,36779,NULL,'laboratory-discussion',52,'2012-03-29 00:21:40','2012-03-29 00:21:40','AY1','ACCY','Assurance and Attestation',405,1,1,NULL,NULL,NULL,NULL,65,'LBD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(150,49130,NULL,'lecture-discussion',53,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Advanced Income Tax Problems',451,1,2,NULL,NULL,NULL,NULL,66,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(151,54569,NULL,'lecture-discussion',53,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Advanced Income Tax Problems',451,1,2,NULL,NULL,NULL,NULL,67,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(152,10038,NULL,'independent study',54,'2012-03-29 00:21:40','2012-03-29 00:21:40','NO CODE','ACCY','Senior Research',499,1,2,NULL,NULL,NULL,NULL,68,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(153,49763,NULL,'lecture-discussion',55,'2012-03-29 00:21:40','2012-03-29 00:21:40','MSF','ACCY','Atg Measuremnt, Rpting & Cntrl',500,1,2,NULL,NULL,NULL,NULL,69,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(154,49761,NULL,'lecture-discussion',55,'2012-03-29 00:21:40','2012-03-29 00:21:40','MT ','ACCY','Atg Measuremnt, Rpting & Cntrl',500,1,2,NULL,NULL,NULL,NULL,69,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(155,58446,NULL,'lecture-discussion',55,'2012-03-29 00:21:40','2012-03-29 00:21:40','MT1','ACCY','Atg Measuremnt, Rpting & Cntrl',500,1,2,NULL,NULL,NULL,NULL,69,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(156,29680,NULL,'lecture-discussion',56,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Accounting Analysis II',502,1,2,NULL,NULL,NULL,NULL,70,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(157,31334,NULL,'lecture-discussion',56,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Accounting Analysis II',502,1,2,NULL,NULL,NULL,NULL,71,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(158,31335,NULL,'lecture-discussion',57,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Managerial Accounting',503,1,2,NULL,NULL,NULL,NULL,72,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(159,39540,NULL,'lecture-discussion',57,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Managerial Accounting',503,1,2,NULL,NULL,NULL,NULL,73,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(160,56299,NULL,'lecture-discussion',58,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Auditing',504,1,2,NULL,NULL,NULL,NULL,74,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(161,31339,NULL,'lecture-discussion',59,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Federal Taxation',505,1,2,NULL,NULL,NULL,NULL,75,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(162,31341,NULL,'lecture-discussion',59,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Federal Taxation',505,1,2,NULL,NULL,NULL,NULL,76,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(163,54993,NULL,'lecture-discussion',59,'2012-03-29 00:21:40','2012-03-29 00:21:40','C  ','ACCY','Federal Taxation',505,1,2,NULL,NULL,NULL,NULL,77,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(164,46973,NULL,'lecture-discussion',60,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Financial Reporting Standards',510,1,2,NULL,NULL,NULL,NULL,78,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(165,46974,NULL,'lecture-discussion',60,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Financial Reporting Standards',510,1,2,NULL,NULL,NULL,NULL,79,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(166,46975,NULL,'lecture-discussion',60,'2012-03-29 00:21:40','2012-03-29 00:21:40','C  ','ACCY','Financial Reporting Standards',510,1,2,NULL,NULL,NULL,NULL,80,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(167,49275,NULL,'lecture-discussion',60,'2012-03-29 00:21:40','2012-03-29 00:21:40','D  ','ACCY','Financial Reporting Standards',510,1,1,NULL,NULL,NULL,NULL,81,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(168,49276,NULL,'lecture-discussion',61,'2012-03-29 00:21:40','2012-03-29 00:21:40','E  ','ACCY','Risk Measurement/Reporting I',511,1,2,NULL,NULL,NULL,NULL,82,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(169,51813,NULL,'lecture-discussion',62,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Risk Measurement/Reporting II',512,1,2,NULL,NULL,NULL,NULL,83,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(170,51814,NULL,'lecture-discussion',62,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Risk Measurement/Reporting II',512,1,2,NULL,NULL,NULL,NULL,84,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(171,51815,NULL,'lecture-discussion',62,'2012-03-29 00:21:40','2012-03-29 00:21:40','C  ','ACCY','Risk Measurement/Reporting II',512,1,2,NULL,NULL,NULL,NULL,85,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(172,51816,NULL,'lecture-discussion',62,'2012-03-29 00:21:40','2012-03-29 00:21:40','D  ','ACCY','Risk Measurement/Reporting II',512,1,2,NULL,NULL,NULL,NULL,86,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(173,51817,NULL,'lecture-discussion',62,'2012-03-29 00:21:40','2012-03-29 00:21:40','E  ','ACCY','Risk Measurement/Reporting II',512,1,2,NULL,NULL,NULL,NULL,87,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(174,51818,NULL,'lecture-discussion',62,'2012-03-29 00:21:40','2012-03-29 00:21:40','F  ','ACCY','Risk Measurement/Reporting II',512,1,2,NULL,NULL,NULL,NULL,88,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(175,46977,NULL,'lecture-discussion',63,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Auditing & Assurance Standards',515,1,2,NULL,NULL,NULL,NULL,89,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(176,54477,NULL,'lecture-discussion',63,'2012-03-29 00:21:40','2012-03-29 00:21:40','C  ','ACCY','Auditing & Assurance Standards',515,1,2,NULL,NULL,NULL,NULL,90,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(177,31373,NULL,'lecture-discussion',64,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Financial Statement Analysis',517,1,2,NULL,NULL,NULL,'Departmental Approval Required',91,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(178,31377,NULL,'lecture-discussion',64,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Financial Statement Analysis',517,1,2,NULL,NULL,NULL,NULL,92,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(179,39543,NULL,'lecture-discussion',64,'2012-03-29 00:21:40','2012-03-29 00:21:40','C  ','ACCY','Financial Statement Analysis',517,1,2,NULL,NULL,NULL,NULL,93,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(180,44169,NULL,'lecture-discussion',65,'2012-03-29 00:21:40','2012-03-29 00:21:40','CHI','ACCY','Partnership Income Taxation',552,1,2,NULL,NULL,NULL,NULL,94,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(181,50799,NULL,'lecture-discussion',66,'2012-03-29 00:21:40','2012-03-29 00:21:40','CH2','ACCY','Selected Topics in Fed Tax',553,1,2,NULL,NULL,NULL,NULL,95,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(182,48329,NULL,'lecture-discussion',66,'2012-03-29 00:21:40','2012-03-29 00:21:40','CHI','ACCY','Selected Topics in Fed Tax',553,1,2,NULL,NULL,NULL,NULL,95,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(183,54570,NULL,'lecture-discussion',67,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Tax Research',556,1,2,NULL,NULL,NULL,NULL,96,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(184,31384,NULL,'lecture-discussion',67,'2012-03-29 00:21:40','2012-03-29 00:21:40','B  ','ACCY','Tax Research',556,1,2,NULL,NULL,NULL,NULL,97,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(185,47788,NULL,'lecture-discussion',68,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Constructs in Atg Research',585,1,2,NULL,NULL,NULL,NULL,98,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(186,29682,NULL,'lecture-discussion',69,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Intro to ACCY Research',592,1,2,NULL,NULL,NULL,NULL,99,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(187,10041,NULL,'independent study',70,'2012-03-29 00:21:40','2012-03-29 00:21:40','NO CODE','ACCY','Special Research Problems',593,1,2,NULL,NULL,NULL,'Departmental Approval Required',100,'IND',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(188,45793,NULL,'lecture-discussion',70,'2012-03-29 00:21:40','2012-03-29 00:21:40','AT1','ACCY','Special Research Problems',593,1,2,NULL,NULL,NULL,'Departmental Approval Required',101,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(189,48244,NULL,'lecture-discussion',70,'2012-03-29 00:21:40','2012-03-29 00:21:40','AT2','ACCY','Special Research Problems',593,1,2,NULL,NULL,NULL,'Departmental Approval Required',101,'S1 ',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(190,50546,NULL,'lecture-discussion',70,'2012-03-29 00:21:40','2012-03-29 00:21:40','C  ','ACCY','Special Research Problems',593,1,2,NULL,NULL,NULL,NULL,102,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(191,54478,NULL,'lecture-discussion',70,'2012-03-29 00:21:40','2012-03-29 00:21:40','FR ','ACCY','Special Research Problems',593,1,2,NULL,NULL,NULL,NULL,103,'LCD',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(192,42664,NULL,'conference',70,'2012-03-29 00:21:40','2012-03-29 00:21:40','S  ','ACCY','Special Research Problems',593,1,2,NULL,NULL,NULL,'Departmental Approval Required',104,'CNF',1,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(193,29684,NULL,'lecture-discussion',71,'2012-03-29 00:21:40','2012-03-29 00:21:40','A  ','ACCY','Doctoral Research Seminar',594,1,2,NULL,NULL,NULL,NULL,105,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00'),(194,29686,NULL,'lecture-discussion',72,'2012-03-29 00:21:40','2012-03-29 00:21:40','1  ','ACCY','Thesis Research',599,1,2,NULL,NULL,NULL,NULL,106,'LCD',0,'2012-08-27 05:00:00','2012-12-12 06:00:00');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_meetings`
--

DROP TABLE IF EXISTS `sections_meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_meetings` (
  `sections_id` int(11) DEFAULT NULL,
  `meetings_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_meetings`
--

LOCK TABLES `sections_meetings` WRITE;
/*!40000 ALTER TABLE `sections_meetings` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections_meetings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semesters`
--

DROP TABLE IF EXISTS `semesters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semesters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `season` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subjects_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semesters`
--

LOCK TABLES `semesters` WRITE;
/*!40000 ALTER TABLE `semesters` DISABLE KEYS */;
INSERT INTO `semesters` VALUES (1,'2012','fall',NULL,'2012-03-29 00:21:25','2012-03-29 00:21:25',NULL);
/*!40000 ALTER TABLE `semesters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `web_site_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` text COLLATE utf8_unicode_ci,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `address1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'www.aasp.uiuc.edu','1208 West Nevada, Urbana','Lisa Nakamura','Director','Asian American Studies','AAS','2012-03-29 00:21:27','2012-03-29 00:21:27','244-9530',1,'Program Office'),(2,'www.age.uiuc.edu','338 Agricultural Engineering Sciences Building, 1304 West Pennsylvania Avenue, Urbana','K. C. Ting','Head of Department','Agricultural and Biological Engineering','ABE','2012-03-29 00:21:32','2012-03-29 00:21:32','333-3570',1,'Department Office'),(3,'www.business.uiuc.edu/accountancy/','360 Wohlers Hall, 1206 South Sixth, Champaign','Theodore Sougiannis','Head of Department','Accountancy','ACCY','2012-03-29 00:21:39','2012-03-29 00:21:39','333-0857',1,'Department Office');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) DEFAULT NULL,
  `fb_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fb_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-03-30  1:09:59
